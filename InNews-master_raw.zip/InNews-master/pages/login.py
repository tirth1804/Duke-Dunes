import streamlit as st
from PIL import Image
from bs4 import BeautifulSoup as soup
from urllib.request import urlopen
from newspaper import Article
import io
import nltk
import pyperclip
nltk.download('punkt')


st.title("Login")
username = st.text_input("Username")
password = st.text_input("Password", type="password")
if st.button("Log In"):
    if username == "000" and password == "000":
        st.success(f"Logged in as {username}")
        current_page = "App"  # Set the current page to "App"
        
    # Implement your login logic here
    st.success(f"Logged in as {username}")