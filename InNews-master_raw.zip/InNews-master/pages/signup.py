import streamlit as st
from PIL import Image
from bs4 import BeautifulSoup as soup
from urllib.request import urlopen
from newspaper import Article
import io
import nltk
import pyperclip
nltk.download('punkt')
from google.oauth2 import id_token
from google.auth.transport import requests

# st.title("Sign Up")
# name = st.text_input("Name")

# username = st.text_input("Username")
# password = st.text_input("Password", type="password")
# if st.button("Sign Up"):
#     # Implement your login logic here
#     st.success(f"Logged in as {username}")



# Define a function for Google OAuth2 authentication
# def authenticate_with_google():
    # Implement your Google OAuth2 authentication logic here
    # You can use third-party libraries or services like OAuth2
    # to handle the authentication process.

st.title("Sign Up")
name = st.text_input("Name")
username = st.text_input("Username")
password = st.text_input("Password", type="password")

# Add a "Sign Up with Google" button
# if st.button("Sign Up"):
    # Implement your sign-up logic here
    # st.success(f"Account created for {username}")

# Add a "Sign Up with Google" button
# if st.button("Sign Up with Google"):
#     # Call the authentication function
#     authenticate_with_google()

    # st.title("Your Streamlit App")
    
    # Google Authentication
st.subheader("Google Authentication")
client_id = "650627225-706vcvsv6ssp05kolbhj6cgvamkg868n.apps.googleusercontent.com"  # Replace with your OAuth client ID
token = st.text_input("Enter your Google ID token", type="password")
if st.button("Authenticate"):
    try:
        idinfo = id_token.verify_oauth2_token(token, requests.Request(), client_id)
        if idinfo['aud'] != client_id:
            raise ValueError("Invalid client ID")
        st.success(f"Authentication successful: {idinfo['name']}")
        # Continue with the rest of your app logic here
    except ValueError as e:
        st.error("Authentication failed")
        st.error(e)
